// Blog Data
const blogPosts = {
    destaque: [
        {
            title: "Novas Regras Fiscais para 2026 em Angola",
            category: "Fiscalidade",
            date: "15 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&q=80",
            excerpt: "Conheça as principais alterações fiscais que entram em vigor este ano."
        },
        {
            title: "Como Otimizar a Contabilidade da Sua Empresa",
            category: "Contabilidade",
            date: "10 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1554224154-26032ffc0d07?w=600&q=80",
            excerpt: "Dicas essenciais para uma gestão contabilística mais eficiente."
        },
        {
            title: "Tendências em Gestão de RH para 2026",
            category: "RH",
            date: "5 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&q=80",
            excerpt: "As principais tendências que vão moldar a gestão de recursos humanos."
        }
    ],
    fiscalidade: [
        {
            title: "Planeamento Fiscal: Estratégias para PMEs",
            category: "Fiscalidade",
            date: "20 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1554224311-beee415c201f?w=600&q=80",
            excerpt: "Como as pequenas e médias empresas podem otimizar a sua carga fiscal."
        },
        {
            title: "IVA em Angola: Guia Completo",
            category: "Fiscalidade",
            date: "18 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=600&q=80",
            excerpt: "Tudo o que precisa saber sobre o Imposto sobre o Valor Acrescentado."
        },
        {
            title: "Benefícios Fiscais para Investidores",
            category: "Fiscalidade",
            date: "12 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=600&q=80",
            excerpt: "Descubra os incentivos fiscais disponíveis para investimento em Angola."
        }
    ],
    contabilidade: [
        {
            title: "Fecho de Contas: Checklist Essencial",
            category: "Contabilidade",
            date: "22 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=600&q=80",
            excerpt: "Não deixe nada para trás no fecho de contas anual da sua empresa."
        },
        {
            title: "Relatórios Financeiros que Importam",
            category: "Contabilidade",
            date: "14 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&q=80",
            excerpt: "Os principais relatórios financeiros para tomada de decisão."
        },
        {
            title: "Controlo de Custos na Prática",
            category: "Contabilidade",
            date: "8 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=600&q=80",
            excerpt: "Técnicas comprovadas para reduzir custos sem comprometer a qualidade."
        }
    ],
    rh: [
        {
            title: "Processamento Salarial: Boas Práticas",
            category: "RH",
            date: "25 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=600&q=80",
            excerpt: "Como garantir um processamento salarial eficiente e sem erros."
        },
        {
            title: "Recrutamento Eficaz em 2026",
            category: "RH",
            date: "16 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=600&q=80",
            excerpt: "Estratégias modernas para atrair e reter os melhores talentos."
        },
        {
            title: "Gestão de Benefícios: Guia Completo",
            category: "RH",
            date: "11 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=600&q=80",
            excerpt: "Como estruturar um pacote de benefícios atrativo para colaboradores."
        }
    ],
    recentes: [
        {
            title: "Digitalização da Contabilidade em Angola",
            category: "Contabilidade",
            date: "28 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&q=80",
            excerpt: "A transformação digital está a revolucionar a contabilidade."
        },
        {
            title: "Reforma Fiscal 2026: O Que Muda",
            category: "Fiscalidade",
            date: "26 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1565688534245-05d6b5be184a?w=600&q=80",
            excerpt: "Análise detalhada das mudanças fiscais previstas para este ano."
        },
        {
            title: "Home Office: Implicações em RH",
            category: "RH",
            date: "24 Janeiro 2026",
            image: "https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=600&q=80",
            excerpt: "Como gerir equipas remotas de forma eficaz e legal."
        }
    ]
};

// Load Blog Posts
function loadBlogPosts(category) {
    const blogGrid = document.getElementById('blogGrid');
    const posts = blogPosts[category] || blogPosts.destaque;
    
    blogGrid.innerHTML = posts.map(post => `
        <div class="blog-card">
            <img src="${post.image}" alt="${post.title}" class="blog-image">
            <div class="blog-card-content">
                <span class="blog-category">${post.category}</span>
                <h3>${post.title}</h3>
                <p style="color: var(--text-light); margin: 1rem 0;">${post.excerpt}</p>
                <p class="blog-date">${post.date}</p>
            </div>
        </div>
    `).join('');
}

// Animate Stats Counter
function animateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        const target = parseInt(stat.dataset.target);
        const duration = 2000;
        const increment = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                stat.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                stat.textContent = target;
            }
        };
        
        updateCounter();
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Load default blog posts
    loadBlogPosts('destaque');
    
    // Animate stats when visible
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateStats();
                observer.unobserve(entry.target);
            }
        });
    });
    
    const statsSection = document.querySelector('.stats');
    if (statsSection) {
        observer.observe(statsSection);
    }
    
    // Blog Category Filter
    document.querySelectorAll('.blog-category-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.blog-category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            loadBlogPosts(this.dataset.category);
        });
    });
    
    // FAQ Toggle
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', function() {
            const faqItem = this.parentElement;
            faqItem.classList.toggle('active');
        });
    });
    
    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
    
    // Navbar Scroll Effect
    window.addEventListener('scroll', function() {
        const navbar = document.getElementById('navbar');
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Form Submission
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Check business hours
            if (data.hora) {
                const selectedTime = data.hora;
                const [hours, minutes] = selectedTime.split(':').map(Number);
                
                if (hours < 8 || hours >= 19) {
                    showErrorModal('Estamos fechados nesse horário. Por favor, agende entre 08:00 e 19:00.');
                    return;
                }
            }
            
            // Simulate backend processing
            const appointmentData = {
                ...data,
                timestamp: new Date().toISOString()
            };
            
            // In a real implementation, this would send to a backend
            console.log('Appointment Data:', appointmentData);
            
            // Send notification (simulated)
            sendAppointmentNotification(appointmentData);
            
            // Show success modal
            showSuccessModal(data);
            
            // Reset form
            this.reset();
        });
    }
});

function sendAppointmentNotification(data) {
    // In a real implementation, this would:
    // 1. Send SMS to owner: +244 934 465 141
    // 2. Send email to: geralemmconsultoria@gmail.com
    // 3. Send confirmation to client
    
    const ownerMessage = `Nova reunião agendada!
Nome: ${data.nome}
Data: ${data.data}
Hora: ${data.hora}
Serviço: ${data.servico}
Telefone: ${data.telefone}`;
    
    console.log('SMS to owner:', ownerMessage);
    console.log('Email sent to owner and client');
    
    // Here you would integrate with:
    // - SMS API (Twilio, etc.)
    // - Email API (SendGrid, etc.)
    // - WhatsApp Business API
}

function showSuccessModal(data) {
    const modal = document.getElementById('successModal');
    const message = document.getElementById('modalMessage');
    message.textContent = `A sua reunião foi agendada para ${data.data} às ${data.hora}. Receberá uma confirmação por email e SMS em breve.`;
    modal.classList.add('active');
}

function showErrorModal(message) {
    const modal = document.getElementById('errorModal');
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    modal.classList.add('active');
}

function closeModal() {
    document.getElementById('successModal').classList.remove('active');
}

function closeErrorModal() {
    document.getElementById('errorModal').classList.remove('active');
}
